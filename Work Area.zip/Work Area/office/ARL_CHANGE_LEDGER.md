# ARL Change Ledger

## Change format

Each change must include:
- Date
- Run
- Files changed
- Change type
- Reason
- Risks
- Tests required
- Lock impact

---

## 2026-05-06 — ARL-RUN001 Office Pack Created

Run:
ARL-RUN001-OFFICE-PACK

Files created:
- README.md
- ARL_OFFICE_INDEX.md
- ARL_DECISIONS.md
- ARL_CHANGE_LEDGER.md
- ARL_ROADMAP.md
- ARL_BUILD_PLAN.md
- ARL_REFRESH_TIMING_MODEL.md
- ARL_ATOMIC_PUBLICATION_MODEL.md
- ARL_ACCOUNT_EXPOSURE_REQUIREMENTS.md
- ARL_RESEARCH_LEDGER.md
- ARL_MIGRATION_REGISTER.md
- ARL_RISK_LEDGER.md
- ARL_ACCEPTANCE_TESTS.md
- ARL_LOCK_POLICY.md
- ARL_OUTPUT_SCAFFOLD_SAMPLES.md
- ARL_OPEN_QUESTIONS.md

Change type:
Planning / office foundation.

Reason:
User requested a downloadable office file set to keep roadmap and change records before Codex begins scaffold work.

Risks:
- Office prose may become stale if not updated.
- Too many office files can become bureaucracy if not enforced.
- Future agents may skip mandatory reads.

Tests required:
- Confirm files are added to Git.
- Future prompt must require reading office files first.
- First Codex scaffold run must update CHANGE_LEDGER and DECISIONS if it changes scope.

Lock impact:
No source locks created yet.

---

## 2026-05-06 — ARL-RUN005 Work Area Foundation Alignment

Run:
ARL-RUN005-WORK-AREA-FOUNDATION-ALIGNMENT

Files changed:
- mt5/ARL_Core.mq5
- mt5/core/ARL_Version.mqh
- mt5/README.md
- mt5/MT5_VERSION_POLICY.md
- office/ARL_CHANGE_LEDGER.md
- office/ARL_DECISIONS.md
- office/ARL_RESEARCH_LEDGER.md
- office/ARL_RISK_LEDGER.md
- office/ARL_ACCEPTANCE_TESTS.md
- office/ARL_BUILD_PLAN.md
- office/ARL_OPEN_QUESTIONS.md
- roadmap/ARL_RUN_PROTOCOL.md
- roadmap/ARL_GPT_ZIP_WORKFLOW.md
- roadmap/ARL_TESTING_STRATEGY.md
- roadmap/ARL_CODEX_PROMPT_RULES.md
- blueprint/ARL_SOURCE_TRUTH_AUTHORITY.md
- blueprint/ARL_ATOMIC_PUBLICATION_BLUEPRINT.md
- blueprint/ARL_RETRY_AND_SCHEDULING_BLUEPRINT.md
- ARL_RUN005_REPORT.md

Change type:
Maintenance / source-truth alignment / documentation hardening.

Reason:
The uploaded Work Area zip had compiled scaffold evidence from the user, but product identity was internally inconsistent: `ARL_Core.mq5` declared `#property version "1.004"` while `core/ARL_Version.mqh`, the EA description, and MT5 README still reported `0.0.4`. That is a source-of-truth failure even before runtime logic exists.

Risks:
- Live internet research was requested but unavailable in this chat environment, so official-source research could not be freshly verified here.
- MetaEditor compile was not available in this environment, so compile proof was not upgraded.
- `ARL_Core.ex5` was present in the upload but was not modified; binary compile state cannot be verified here.

Tests required:
- Open `Work Area/mt5/ARL_Core.mq5` in MetaEditor and compile.
- Confirm EA properties show `#property version` as `1.004`.
- Confirm startup print from `ARL_VersionLine()` reports `1.004`.
- Confirm no HUD/trading/signal/execution/risk permission was added.
- Confirm output zip excludes Archives.

Lock impact:
No module lock created. This run aligns source identity and process records only.

## 2026-05-06 — ARL-RUN007 Pre-Work Unification Alignment

Run id: `ARL-RUN007-PRE-WORK-UNIFICATION-ALIGNMENT`.

Purpose: unify Work Area source records before implementation starts.

Changed/added records:
- aligned MT5 product run identity to `ARL-RUN007` while keeping product version `1.004`;
- recorded Git summary/description standard with proper header plus deep structured description;
- confirmed RUN006 trader-data reference files are present in the uploaded Work Area package;
- strengthened trader-data-first law across office, roadmap, and blueprint references;
- recorded archive policy: `Archives/` are Git-only inheritance evidence and must not be included in uploaded Work Area zips;
- added RUN007 report and run plan.

Version impact: `1.004` retained because no runtime behavior, trading, signal, execution, HUD, or strategy formulas were added.

Proof boundary: static include scan and duplicate-function scan may be recorded by this run. No compile proof exists unless MetaEditor compile output is supplied.

---

## 2026-05-06 — ARL-RUN008 Index + GPT-Codex-Agent Guide System

Run:
ARL-RUN008-INDEX-GPT-CODEX-AGENT-GUIDE-SYSTEM

Files added:
- `AGENTS.md`
- `Work Area/WORK_AREA_INDEX.md`
- `Work Area/GPT_CODEX_README.md`
- `Work Area/office/ARL_MANDATORY_READ_INDEX.md`
- `Work Area/roadmap/ARL_GPT_CODEX_AGENT_GUIDE.md`
- `Work Area/roadmap/ARL_PROMPT_MASTER_CHECKLIST.md`
- `Work Area/roadmap/ARL_GIT_SUMMARY_DESCRIPTION_STANDARD.md`
- `Work Area/blueprint/ARL_OUTPUT_REFERENCE_INDEX.md`
- `Work Area/mt5/MT5_AGENT_IMPLEMENTATION_GUIDE.md`
- `Work Area/ARL_RUN008_REPORT.md`

Files changed:
- `Work Area/office/ARL_OFFICE_INDEX.md`
- `Work Area/office/ARL_CHANGE_LEDGER.md`
- `Work Area/office/ARL_DECISIONS.md`
- `Work Area/office/ARL_RESEARCH_LEDGER.md`
- `Work Area/office/ARL_RISK_LEDGER.md`
- `Work Area/roadmap/ARL_ROADMAP_INDEX.md`
- `Work Area/blueprint/ARL_BLUEPRINT_INDEX.md`
- `Work Area/mt5/README.md`

Change type:
Documentation / agent-guidance / repository instruction spine.

Reason:
Future GPT, Codex, and automation-agent runs needed a durable read-before-edit system, source authority map, prompt-master checklist, Git summary/description standard, and MT5 implementation boundary guide before real implementation work continues.

Risks:
- Guidance can still be skipped by an agent unless prompts explicitly enforce `AGENTS.md` and `ARL_MANDATORY_READ_INDEX.md`.
- Git main may lag behind uploaded Work Area packages; contradictions must continue to be logged instead of silently resolved.
- Documentation can become stale if future runs change source behavior without updating indexes.

Tests required:
- Confirm all new guide/index files exist.
- Confirm mandatory-read paths are consistent.
- Confirm no MT5 behavior source files changed.
- Confirm product version remains unchanged.
- Confirm output zip excludes Archives and binaries.

Lock impact:
No MT5 module locks created. This run creates guidance/control records only.


---

## 2026-05-06 — ARL-RUN009 Runtime IO Foundation + Atomic Status Publication

Run:
`ARL-RUN009-RUNTIME-IO-FOUNDATION-ATOMIC-STATUS-PUBLICATION`

Changed source behavior:
- advanced active MT5 product identity from `1.004` to `1.005`;
- connected `OnTimer()` to bounded heartbeat, bounded scheduler tick, status publication, manifest publication, and runtime cycle metrics;
- implemented `Status_Current.json` and `Manifest_Current.json` publication through staged temp writes, flush/close, readback, promote, final readback, and no-change skip support;
- kept all permissions false: no trading, no signals, no execution, no HUD.

Files changed:
- `mt5/ARL_Core.mq5`
- `mt5/core/ARL_Version.mqh`
- `mt5/runtime/ARL_Heartbeat.mqh`
- `mt5/runtime/ARL_Scheduler.mqh`
- `mt5/io/ARL_Paths.mqh`
- `mt5/io/ARL_FilePublisher.mqh`
- `mt5/io/ARL_PublicationManifest.mqh`
- `mt5/io/ARL_PayloadHash.mqh`
- `mt5/io/ARL_OutputContracts.mqh`
- `mt5/telemetry/ARL_StatusWriter.mqh`
- `mt5/telemetry/ARL_ErrorLedger.mqh`
- `mt5/telemetry/ARL_FunctionResults.mqh`
- `mt5/telemetry/ARL_RuntimeMetrics.mqh`
- `mt5/MT5_VERSION_POLICY.md`
- office/roadmap/blueprint acceptance records
- `reports/ARL_RUN009_REPORT.md`

Boundary:
No account snapshot, Market Watch universe, layer work, Market Board, Symbol Trader Pack, Dossier, HUD, trading, signal, execution, strategy formula, archive copy, or changelog `.mqh` was added.

Proof boundary:
Static validation passed in this environment. MetaEditor compile and MT5 runtime attachment were unavailable, so this run does not claim compile proof or runtime proof.


---

## 2026-05-06 — ARL-RUN010R Runtime IO Compile Repair + Path String Fix

Run:
`ARL-RUN010R-RUNTIME-IO-COMPILE-REPAIR-PATH-STRING-FIX`

Changed source behavior:
- repaired malformed path string literals in `mt5/io/ARL_Paths.mqh` by replacing raw backslash separators with compile-safe `/` separators;
- repaired malformed JSON quote construction in `mt5/io/ARL_FilePublisher.mqh`, `mt5/io/ARL_PublicationManifest.mqh`, and `mt5/telemetry/ARL_StatusWriter.mqh`;
- reordered dependent includes in `mt5/ARL_Core.mq5` so payload hash/output contracts/error ledger/runtime metrics are declared before consumers;
- aligned main EA `#property version` and description with existing `ARL_PRODUCT_VERSION=1.005` / `ARL_PRODUCT_RUN_ID=ARL-RUN009` policy.

Files changed:
- `mt5/ARL_Core.mq5`
- `mt5/io/ARL_Paths.mqh`
- `mt5/io/ARL_FilePublisher.mqh`
- `mt5/io/ARL_PublicationManifest.mqh`
- `mt5/telemetry/ARL_StatusWriter.mqh`
- `roadmap/ARL_ROADMAP_COMPLETION_STATUS.md`
- `office/ARL_CHANGE_LEDGER.md`
- `office/ARL_DECISIONS.md`
- `office/ARL_RESEARCH_LEDGER.md`
- `office/ARL_RISK_LEDGER.md`
- `office/ARL_ACCEPTANCE_TESTS.md`
- `reports/ARL_RUN010R_REPORT.md`

Boundary:
No account scanning, universe implementation, market layers, indicators, ranking, Market Board, Symbol Trader Pack, Dossier, HUD, trading, signals, execution, strategy formula, archive copy, or changelog `.mqh` was added.

Proof boundary:
Static quote/brace validation passed in this environment. MetaEditor compile and MT5 runtime were unavailable, so this run does not claim compile proof or runtime proof.

---

## 2026-05-06 — ARL-RUN011 Runtime Output Path Verification + Status/Manifest Write Smoke Prep

Run:
`ARL-RUN011-RUNTIME-OUTPUT-PATH-VERIFICATION-STATUS-MANIFEST-WRITE-SMOKE`

Changed source behavior:
- advanced active MT5 product identity from `1.005` to `1.006` because the timer runtime path now actively calls status/manifest publication;
- repaired the missing runtime publication call by wiring `ARL_StatusWriter_Publish()` into `OnTimer()` after heartbeat and scheduler ticks;
- initialized paths, output contracts, publisher, manifest, runtime metrics, and status writer during `OnInit()`;
- added startup path diagnostics through `Print()` so the Experts log reports file mode, common-files base, and current status/manifest relative paths;
- added status payload path fields for file location mode, status final/temp path, and manifest final/temp path;
- added manifest `file_location_mode` field;
- strengthened publisher failure/success messages to include final and temp paths.

Files changed:
- `mt5/ARL_Core.mq5`
- `mt5/core/ARL_Version.mqh`
- `mt5/io/ARL_Paths.mqh`
- `mt5/io/ARL_FilePublisher.mqh`
- `mt5/io/ARL_PublicationManifest.mqh`
- `mt5/telemetry/ARL_StatusWriter.mqh`
- `office/ARL_CHANGE_LEDGER.md`
- `office/ARL_DECISIONS.md`
- `office/ARL_RESEARCH_LEDGER.md`
- `office/ARL_RISK_LEDGER.md`
- `office/ARL_ACCEPTANCE_TESTS.md`
- `roadmap/ARL_ROADMAP_COMPLETION_STATUS.md`
- `brain/AURORA_CODING_BRAIN_GUIDEBOOK.md`
- `brain/AURORA_FAILURE_PATTERNS_GUIDEBOOK.md`
- `reports/ARL_RUN011_REPORT.md`

Boundary:
No account scanning, universe implementation, market layers, indicators, ranking, Market Board, Symbol Trader Pack, Dossier, HUD, trading, signals, execution, strategy formulas, archive copy, duplicate publisher, duplicate status writer, new route, or changelog `.mqh` was added.

Proof boundary:
User supplied RUN010R compile evidence for the incoming baseline: `0 errors, 0 warnings, 491 ms elapsed`. RUN011 changed source behavior after that compile, so current RUN011 source still requires MetaEditor compile and MT5 runtime smoke before runtime output proof can be claimed.


---

## ARL-RUN011R — Runtime file-write failure repair

Date: 2026-05-06

Changed:
- `mt5/io/ARL_Paths.mqh`: added canonical output-folder helpers, expected absolute Common Files path patterns, and level-by-level `FILE_COMMON` folder-chain creation for `Aurora Reforged Lattice/Default/Current`.
- `mt5/io/ARL_FilePublisher.mqh`: added startup diagnostics, flat `ARL_RuntimeWriteProbe.txt` common-files probe, pre-write folder-chain creation, publish attempt/result logging, and folder diagnostics in publish results.
- `mt5/telemetry/ARL_StatusWriter.mqh`: added disabled-write logging, expanded path diagnostics in status payload, JSON path escaping, and failure-loud status/manifest result logs.
- `mt5/io/ARL_PublicationManifest.mqh`: updated run header to RUN011R diagnostics scope; manifest continues through the single publisher route.
- `mt5/ARL_Core.mq5`: added startup prints for expected Common Files status/manifest paths and disabled-write operator warning.
- `roadmap/ARL_ROADMAP_COMPLETION_STATUS.md`: updated runtime IO source-evidence status only.

Not changed:
- No trading, signals, execution, HUD, account scanning, ranking, Market Board, Dossier, or archive migration.
- Product version remained `1.006`.

Proof boundary:
Source patch only. Compile and runtime output remain unproven until user/agent runs MetaEditor and MT5 smoke.
